﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Caralho : MonoBehaviour
{

    public GameObject what;
    public Transform generationPoitn;
    public float maxDis;
    private float thicc;

    // Start is called before the first frame update
    void Start()
    {
        thicc=what.GetComponent<BoxCollider2D>().size.y;
    }

    // Update is called once per frame
    void Update()
    {
        if(transform.position.y>generationPoitn.position.y){
            transform.position=new Vector3(Random.Range(-10,11),transform.position.y-maxDis-thicc,transform.position.z);
            Instantiate(what,transform.position,transform.rotation);
        }
    }
}
