﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MostrarTexto : MonoBehaviour
{

    public Text texto;
    public Seguiri contador;
    public float max;

    // Start is called before the first frame update
    void Start()
    {
        texto.text=""+(long)contador.toi;
        max=0;
    } 

    // Update is called once per frame
    void Update()
    {
        texto.text=""+contador.toi;
        if(contador.toi>max)
        max=contador.toi;
    }
    public void reiniciarTexto(){
        contador.reiniciarTime();
    }
}
