﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Morir : MonoBehaviour
{
    public Transform generadorP;
    private Vector3 inicioP;
    public Ponselo vaca;
    public Vector3 inicioV;
    public float sAntes;
    public float sDespues;
    public float que;
    public float este;
    
    // Start is called before the first frame update
    void Start()
    {
        inicioP=generadorP.position;
        inicioV=vaca.transform.position;
        sDespues=0;
        que=200;
        este=0;
    }

    // Update is called once per frame
    void Update()
    {
        if(vaca.muerte){
            este++;
            if(este>=que){
                este=0;
                vaca.transform.position=inicioV;
                vaca.muerte=false;
                generadorP.position=inicioP;
            }
        }
    }
}
  

