﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ponselo : MonoBehaviour
{
    public float multiplicador=5f;
    public Rigidbody2D rb;
    public float mm;
    public bool salto;
    public bool muerte;
    public Transform inicio;

    public Animator animador;
    // Start is called before the first frame update
    void Start()
    {
        animador = GetComponent<Animator>();
        animador.SetBool("saltar",false);
        animador.SetBool("muerte",false);
        rb=GetComponent<Rigidbody2D>();
        salto=false;
        muerte=false;
        inicio=GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
            mm=Input.GetAxis("Horizontal")*multiplicador;
            if(Input.GetKey(KeyCode.Space)){
                salto=true;
                animador.SetBool("saltar",true);
                Vector2 v=rb.velocity;
                v.y=rb.velocity.y/2;
                rb.velocity=v;
            }else{
                salto=false;
                animador.SetBool("saltar",false);
            }

           
    }



    void FixedUpdate(){
        if(!muerte){
            Vector2 v=rb.velocity;
            v.x=mm;
            rb.velocity=v;
        }else{
            Vector2 v=rb.velocity;
            v.x=0;
            rb.velocity=v;
        }
    }



    void OnCollisionEnter2D(Collision2D col){
        if(col.collider.sharedMaterial.name=="Muerte"){
            animador.SetBool("muerte",true);
            muerte=true;
        }
    }
    void OnCollisionExit2D(Collision2D col){
        if(col.collider.sharedMaterial.name=="Muerte"){
            animador.SetBool("muerte",false);
            animador.SetBool("saltar",false);
        }
    }
    
}