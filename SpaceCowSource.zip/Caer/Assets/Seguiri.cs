﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Seguiri : MonoBehaviour
{
    public GameObject deliveroo;
    public float y;
    public float anitgua;
    public float dif;
    public float total;
    public float toi;
    public float xxx;
    // Start is called before the first frame update
    void Start()
    {
        deliveroo=GameObject.Find("cow3");
        anitgua=deliveroo.transform.position.y;
        xxx=deliveroo.transform.position.x;
        total=0;
        toi=total*100;
    }

    // Update is called once per frame
    void Update()
    {
        y=deliveroo.transform.position.y;
        dif=anitgua-y;
        total+=dif;
        toi=total*100;
        anitgua=deliveroo.transform.position.y;
        transform.position=new Vector3(xxx,y,-10);
    }
    public void reiniciarTime(){
        total=0;
    }
}
